<?php

return
	[
		'url_mask' => '',
		'url_prefix' => '',
	];