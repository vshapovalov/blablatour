<?php $__env->startSection('page'); ?>
<div id="colorlib-services">
    <div class="container">
        <div class="row no-gutters">
            <div class="col-md-3 animate-box text-center aside-stretch">
                <div class="services">
							<span class="icon">
								<i class="flaticon-around"></i>
							</span>
                    <h3>Amazing Travel</h3>
                    <p>Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies</p>
                </div>
            </div>
            <div class="col-md-3 animate-box text-center">
                <div class="services">
							<span class="icon">
								<i class="flaticon-boat"></i>
							</span>
                    <h3>Our Cruises</h3>
                    <p>Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies</p>
                </div>
            </div>
            <div class="col-md-3 animate-box text-center">
                <div class="services">
							<span class="icon">
								<i class="flaticon-car"></i>
							</span>
                    <h3>Book Your Trip</h3>
                    <p>Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies</p>
                </div>
            </div>
            <div class="col-md-3 animate-box text-center">
                <div class="services">
							<span class="icon">
								<i class="flaticon-postcard"></i>
							</span>
                    <h3>Nice Support</h3>
                    <p>Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="colorlib-tour colorlib-light-grey">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center colorlib-heading animate-box">
                <h2>Популярные туры</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet earum eligendi minus nihil officia quidem?</p>
            </div>
        </div>
    </div>
    <div class="tour-wrap">
        <?php $__currentLoopData = \App\Tour::take(8)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="#" class="tour-entry animate-box">
            <div class="tour-img" style="background-image: url(<?php echo e($tour->image); ?>);"></div>
            <span class="desc">
                <p class="star">
                    <span>
                        <?php for($i=0;$i<$tour->rating;$i++): ?>
                            <i class="icon-star-full"></i>
                        <?php endfor; ?>
                    </span>
                    545 Отзывов
                </p>
                <h2><?php echo e($tour->title); ?></h2>
                <span class="city"><?php echo e($tour->place); ?></span>
                <span class="price"><?php echo e($tour->price); ?></span>
            </span>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<div id="colorlib-blog">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center colorlib-heading animate-box">
                <h2>Последние публикации блога</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus dicta earum esse velit voluptate voluptatem!</p>
            </div>
        </div>
        <div class="blog-flex">
            <div class="f-entry-img" style="background-image: url(images/blog-3.jpg);">
            </div>
            <div class="blog-entry aside-stretch-right">
                <div class="row">
                    <?php $__currentLoopData = \App\Post::orderBy('created_at', 'desc')->with(['category'])->take(3)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12 animate-box">
                        <a href="blog.html" class="blog-post">
                            <span class="img" style="background-image: url(<?php echo e($post->image); ?>);"></span>
                            <div class="desc">
                                <span class="date"><?php echo e($post->created_at); ?></span>
                                <h3><?php echo e($post->title); ?></h3>
                                <span class="cat"><?php echo e($post->category->title); ?></span>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="colorlib-intro" class="intro-img" style="background-image: url(images/cover-img-1.jpg);" data-stellar-background-ratio="0.5">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-6 animate-box">
                <div class="intro-desc">
                    <div class="text-salebox">
                        <div class="text-lefts">
                            <div class="sale-box">
                                <div class="sale-box-top">
                                    <h2 class="number">45</h2>
                                    <span class="sup-1">%</span>
                                    <span class="sup-2">Off</span>
                                </div>
                                <h2 class="text-sale">Sale</h2>
                            </div>
                        </div>
                        <div class="text-rights">
                            <h3 class="title">Just hurry up limited offer!</h3>
                            <p>Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
                            <p><a href="#" class="btn btn-primary">Book Now</a> <a href="#" class="btn btn-primary btn-outline">Read more</a></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 animate-box">
                <div class="video-wrap">
                    <div class="video colorlib-video" style="background-image: url(images/img_bg_2.jpg);">
                        <a href="https://vimeo.com/channels/staffpicks/93951774" class="popup-vimeo"><i class="icon-video"></i></a>
                        <div class="video-overlay"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="colorlib-hotel">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center colorlib-heading animate-box">
                <h2>Recommended Hotels</h2>
                <p>We love to tell our successful far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 animate-box">
                <div class="owl-carousel">
                    <div class="item">
                        <div class="hotel-entry">
                            <a href="hotels.html" class="hotel-img" style="background-image: url(images/hotel-1.jpg);">
                                <p class="price"><span>$120</span><small> /night</small></p>
                            </a>
                            <div class="desc">
                                <p class="star"><span><i class="icon-star-full"></i><i class="icon-star-full"></i><i class="icon-star-full"></i><i class="icon-star-full"></i><i class="icon-star-full"></i></span> 545 Reviews</p>
                                <h3><a href="#">Hotel Edison</a></h3>
                                <span class="place">New York, USA</span>
                                <p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="hotel-entry">
                            <a href="hotels.html" class="hotel-img" style="background-image: url(images/hotel-2.jpg);">
                                <p class="price"><span>$120</span><small> /night</small></p>
                            </a>
                            <div class="desc">
                                <p class="star"><span><i class="icon-star-full"></i><i class="icon-star-full"></i><i class="icon-star-full"></i><i class="icon-star-full"></i><i class="icon-star-full"></i></span> 545 Reviews</p>
                                <h3><a href="#">Hotel Edison</a></h3>
                                <span class="place">New York, USA</span>
                                <p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="hotel-entry">
                            <a href="hotels.html" class="hotel-img" style="background-image: url(images/hotel-3.jpg);">
                                <p class="price"><span>$120</span><small> /night</small></p>
                            </a>
                            <div class="desc">
                                <p class="star"><span><i class="icon-star-full"></i><i class="icon-star-full"></i><i class="icon-star-full"></i><i class="icon-star-full"></i><i class="icon-star-full"></i></span> 545 Reviews</p>
                                <h3><a href="#">Hotel Edison</a></h3>
                                <span class="place">New York, USA</span>
                                <p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="hotel-entry">
                            <a href="hotels.html" class="hotel-img" style="background-image: url(images/hotel-4.jpg);">
                                <p class="price"><span>$120</span><small> /night</small></p>
                            </a>
                            <div class="desc">
                                <p class="star"><span><i class="icon-star-full"></i><i class="icon-star-full"></i><i class="icon-star-full"></i><i class="icon-star-full"></i><i class="icon-star-full"></i></span> 545 Reviews</p>
                                <h3><a href="#">Hotel Edison</a></h3>
                                <span class="place">New York, USA</span>
                                <p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="colorlib-testimony" class="colorlib-light-grey">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center colorlib-heading animate-box">
                <h2>Наши довольные гости</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium aliquid asperiores cumque, dicta incidunt laborum nam nulla quod velit voluptate?</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-8 col-md-offset-2 animate-box">
                <div class="owl-carousel2">
                    <?php $__currentLoopData = \App\Feedback::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <div class="testimony text-center">
                            <span class="img-user" style="background-image: url(<?php echo e($feedback->image); ?>);"></span>
                            <span class="user"><?php echo e($feedback->name); ?></span>
                            <small><?php echo e($feedback->place); ?></small>
                            <blockquote>
                                <p><?php echo e($feedback->body); ?></p>
                            </blockquote>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>


    
        
            
                
                
            
        
        
            
                
                    
                        
                            
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                
                            
                        
                        
                            
                                
                                    
                                        
                                        
                                    
                                    
                                        
                                        
                                            
                                                
                                                    
                                                    
                                                    
                                                    
                                                
                                            
                                            
                                                
                                                    
                                                    
                                                    
                                                    
                                                
                                            
                                            
                                                
                                                    
                                                    
                                                    
                                                    
                                                
                                            
                                        
                                        
                                    
                                
                            
                        
                    
                

                
                    
                        
                            
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                
                            
                        
                        
                            
                                
                                    
                                        
                                        
                                    
                                    
                                        
                                        
                                            
                                                
                                                    
                                                    
                                                    
                                                    
                                                
                                            
                                            
                                                
                                                    
                                                    
                                                    
                                                    
                                                
                                            
                                            
                                                
                                                    
                                                    
                                                    
                                                    
                                                
                                            
                                        
                                        
                                    
                                
                            
                        
                    
                
            
        
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>