<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" <?php echo $__env->yieldContent('html_attributes'); ?>>
<head >
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->yieldContent('head'); ?>

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Styles -->
    <link href="<?php echo e(url('vendor/vshapovalov/crud/assets/css/admin.css?140')); ?>" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons' rel="stylesheet">

    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
<?php echo e(csrf_field()); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        window.App = {
            baseUrl: "<?php echo e(url('/')); ?>",
            crudPrefix: "<?php echo e(config('cruds.crud_prefix')); ?>",
            mediaPrefix: "<?php echo e(config('cruds.media_prefix')); ?>",
            mediaPath: "<?php echo e(session()->get('media.path', 'uploads')); ?>",
            uploadPath: "<?php echo e('/storage'); ?>",
            locale: "<?php echo e(app()->getLocale()); ?>",
            user: <?php echo json_encode( auth()->user() ); ?>,
            theme: {
                name: "<?php echo e(config('cruds.theme.name')); ?>",
                colors: <?php echo json_encode( config('cruds.theme.colors') ); ?>

            },
            l18n: <?php echo json_encode( __('cruds') ); ?>,
            tinymce: <?php echo json_encode( config('cruds.tinymce') ); ?>

        };


    </script>

    <script src="<?php echo e(url('vendor/vshapovalov/crud/assets/js/admin.js?143')); ?>"></script>
<?php echo $__env->yieldSection(); ?>
</body>
</html>