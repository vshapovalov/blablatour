<?php

Auth::routes();

Crud::routes();

Pages::routes();